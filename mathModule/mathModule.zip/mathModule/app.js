var mathlib = require('./mathlib')();
mathlib.add(100, 100);
mathlib.multiply(60, 40);
mathlib.square(100);
mathlib.random(1, 35);